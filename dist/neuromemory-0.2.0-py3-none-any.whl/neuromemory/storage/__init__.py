"""Object storage abstraction."""

from neuromemory.storage.base import ObjectStorage

__all__ = ["ObjectStorage"]
