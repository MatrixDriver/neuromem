"""NeuroMemory service layer."""
